-- ==========================================
-- Retail Sales & Customer Analytics Schema
-- ==========================================

-- =========
-- SEQUENCES
-- =========
CREATE SEQUENCE customer_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE product_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE order_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE order_item_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE payment_seq START WITH 1 INCREMENT BY 1;

-- ======
-- TABLES
-- ======
CREATE TABLE customers (
    customer_id NUMBER PRIMARY KEY,
    full_name VARCHAR2(100) NOT NULL,
    gender VARCHAR2(10),
    age NUMBER,
    city VARCHAR2(50),
    loyalty_level VARCHAR2(20),
    signup_date DATE
);

CREATE TABLE products (
    product_id NUMBER PRIMARY KEY,
    product_name VARCHAR2(100),
    category VARCHAR2(50),
    price NUMBER(10,2)
);

CREATE TABLE orders (
    order_id NUMBER PRIMARY KEY,
    customer_id NUMBER,
    order_date DATE,
    CONSTRAINT fk_orders_customer
        FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE order_items (
    order_item_id NUMBER PRIMARY KEY,
    order_id NUMBER,
    product_id NUMBER,
    quantity NUMBER,
    CONSTRAINT fk_items_order
        FOREIGN KEY (order_id) REFERENCES orders(order_id),
    CONSTRAINT fk_items_product
        FOREIGN KEY (product_id) REFERENCES products(product_id)
);

CREATE TABLE payments (
    payment_id NUMBER PRIMARY KEY,
    order_id NUMBER,
    payment_method VARCHAR2(20),
    payment_date DATE,
    amount NUMBER(10,2),
    CONSTRAINT fk_payments_order
        FOREIGN KEY (order_id) REFERENCES orders(order_id)
);

-- ===========
-- CONSTRAINTS
-- ===========
ALTER TABLE customers ADD CONSTRAINT chk_gender
CHECK (gender IN ('Male','Female','Other'));

ALTER TABLE customers ADD CONSTRAINT chk_loyalty
CHECK (loyalty_level IN ('Bronze','Silver','Gold','Platinum'));

ALTER TABLE payments ADD CONSTRAINT chk_payment_method
CHECK (payment_method IN ('Cash','Card','Mobile'));

-- ========
-- INDEXES
-- ========
CREATE INDEX idx_orders_customer ON orders(customer_id);
CREATE INDEX idx_orders_date ON orders(order_date);
CREATE INDEX idx_payments_order ON payments(order_id);
CREATE INDEX idx_payments_date ON payments(payment_date);
CREATE INDEX idx_products_category ON products(category);