-- ==========================================
-- Retail Sales Analytics Queries
-- ==========================================

-- 1. Total Revenue
SELECT SUM(amount) AS total_revenue
FROM payments;

-- 2. Monthly Revenue Trend
SELECT 
    TO_CHAR(payment_date, 'YYYY-MM') AS month,
    SUM(amount) AS monthly_revenue
FROM payments
GROUP BY TO_CHAR(payment_date, 'YYYY-MM')
ORDER BY month;

-- 3. Customer Lifetime Value (CLV)
SELECT 
    c.customer_id,
    c.full_name,
    SUM(p.amount) AS lifetime_value
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
JOIN payments p ON o.order_id = p.order_id
GROUP BY c.customer_id, c.full_name
ORDER BY lifetime_value DESC;

-- 4. Top-Selling Products
SELECT 
    p.product_name,
    SUM(oi.quantity) AS units_sold
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
GROUP BY p.product_name
ORDER BY units_sold DESC;

-- 5. Repeat Customers
SELECT 
    customer_id,
    COUNT(order_id) AS total_orders
FROM orders
GROUP BY customer_id
HAVING COUNT(order_id) > 1;

-- 6. Average Order Value (AOV)
SELECT 
    ROUND(SUM(amount) / COUNT(DISTINCT order_id), 2) AS avg_order_value
FROM payments;

-- 7. Rank Customers by Spending (Window Function)
SELECT 
    c.customer_id,
    c.full_name,
    SUM(p.amount) AS total_spent,
    RANK() OVER (ORDER BY SUM(p.amount) DESC) AS spend_rank
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
JOIN payments p ON o.order_id = p.order_id
GROUP BY c.customer_id, c.full_name;