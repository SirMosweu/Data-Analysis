-- ==========================================
-- Sample Data for Retail Sales Analytics
-- ==========================================

-- CUSTOMERS
INSERT INTO customers (full_name, gender, age, city, loyalty_level, signup_date)
VALUES ('Owen Mosweu', 'Male', 23, 'Kasane', 'Gold', DATE '2024-01-15');

INSERT INTO customers (full_name, gender, age, city, loyalty_level, signup_date)
VALUES ('Naledi Dube', 'Female', 29, 'Gaborone', 'Silver', DATE '2024-03-10');

INSERT INTO customers (full_name, gender, age, city, loyalty_level, signup_date)
VALUES ('Thabo Molefe', 'Male', 35, 'Francistown', 'Platinum', DATE '2023-11-05');

INSERT INTO customers (full_name, gender, age, city, loyalty_level, signup_date)
VALUES ('Kagiso Pheko', 'Female', 26, 'Maun', 'Bronze', DATE '2024-06-01');

-- PRODUCTS
INSERT INTO products (product_name, category, price)
VALUES ('Wireless Mouse', 'Electronics', 250.00);

INSERT INTO products (product_name, category, price)
VALUES ('Laptop Bag', 'Accessories', 400.00);

INSERT INTO products (product_name, category, price)
VALUES ('USB-C Cable', 'Electronics', 120.00);

INSERT INTO products (product_name, category, price)
VALUES ('Bluetooth Headphones', 'Electronics', 950.00);

-- ORDERS
INSERT INTO orders (customer_id, order_date)
VALUES (1, DATE '2024-07-01');

INSERT INTO orders (customer_id, order_date)
VALUES (2, DATE '2024-07-03');

INSERT INTO orders (customer_id, order_date)
VALUES (1, DATE '2024-08-10');

INSERT INTO orders (customer_id, order_date)
VALUES (3, DATE '2024-08-15');

-- ORDER ITEMS
INSERT INTO order_items (order_id, product_id, quantity)
VALUES (1, 1, 2);

INSERT INTO order_items (order_id, product_id, quantity)
VALUES (1, 3, 1);

INSERT INTO order_items (order_id, product_id, quantity)
VALUES (2, 2, 1);

INSERT INTO order_items (order_id, product_id, quantity)
VALUES (3, 4, 1);

INSERT INTO order_items (order_id, product_id, quantity)
VALUES (4, 1, 3);

-- PAYMENTS
INSERT INTO payments (order_id, payment_method, payment_date, amount)
VALUES (1, 'Card', DATE '2024-07-01', 620.00);

INSERT INTO payments (order_id, payment_method, payment_date, amount)
VALUES (2, 'Mobile', DATE '2024-07-03', 400.00);

INSERT INTO payments (order_id, payment_method, payment_date, amount)
VALUES (3, 'Card', DATE '2024-08-10', 950.00);

INSERT INTO payments (order_id, payment_method, payment_date, amount)
VALUES (4, 'Cash', DATE '2024-08-15', 750.00);

COMMIT;